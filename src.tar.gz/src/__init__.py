from kine import *
from kine.renderers.wasm import *

from .app import app

async def main():
    await start_wasm(app())
