from kine import *
from kine.renderers.wasm import *

@component
def app(cx: Scope):
    value = use_state(cx, lambda: 0)

    return div(id="container")[
        button(
            onclick=lambda _: value.modify(lambda v: v + 1)
        )[
            "+1"
        ],
        p(id="text")[
            f"{value.get()}"
        ],
        button(
            onclick=lambda _: value.modify(lambda v: v - 1)
        )[
            "-1"
        ],
    ]