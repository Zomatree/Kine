from .styled_components import (
    styled_component as styled_component,
    styled_component_provider as styled_component_provider,
)
